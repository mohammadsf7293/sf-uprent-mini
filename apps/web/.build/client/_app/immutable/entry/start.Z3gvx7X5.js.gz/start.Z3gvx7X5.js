import{a as t}from"../chunks/entry.Be9f5GS3.js";export{t as start};
